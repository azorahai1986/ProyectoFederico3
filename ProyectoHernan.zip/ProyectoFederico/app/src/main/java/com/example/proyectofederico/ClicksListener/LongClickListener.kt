package com.example.proyectofederico.ClicksListener

import android.view.View

interface LongClickListener {
    fun longClick(vista: View, index:Int)

}