package com.example.proyectofederico

class Productos(var imagen: String = "DEFAULT URL", var producto: String = "DEFAULT NAME", var precio: String = "DEFAULT DESC") {

    init {
        this.imagen = imagen
        this.producto = producto
        this.precio = precio
    }
}