package com.example.proyectofederico.Actividades

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.proyectofederico.R
import android.widget.TextView
import com.example.proyectofederico.Productos
import kotlinx.android.synthetic.main.activity_vista_producto.*
import kotlinx.android.synthetic.main.template_lista.*


class VistaProducto : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vista_producto)

        val productos = mutableListOf<Productos>()


        val producto1 = findViewById<TextView>(R.id.textView)
        val precio1 = findViewById<TextView>(R.id.textView2)
        val index = intent.getStringExtra("ID")

        producto1.text






    }
}
