package com.example.proyectofederico

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.proyectofederico.ClicksListener.ClickListener
import com.example.proyectofederico.ClicksListener.LongClickListener
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.template_lista.view.*

class AdaptadorRecycler(items: ArrayList<Productos>, private val context: Context, var listener: ClickListener, var longClickListener: LongClickListener): RecyclerView.Adapter<AdaptadorRecycler.MainViewHolder>() {


    private var dataList = mutableListOf<Productos>()

    fun setListData(data: MutableList<Productos>){
        dataList =  data // con esto cree la lista y la seteo

    }
    //para darle click a mi lista
    var viewHolder: RecyclerView.ViewHolder? = null // 27 cambio el val por var
    init {
        this.dataList = items
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.template_lista, parent, false)
        viewHolder = MainViewHolder(itemView, listener, longClickListener)//10. me a dar un error aca. debo agregar mi listener. y agregarlo tambien en class AdaptadorCustom
        //  23. el adapatador en el MainActivity tambien me lo va a pedir.
        return MainViewHolder(itemView, listener, longClickListener)
    }

    override fun getItemCount(): Int {

        return if (dataList.size > 0){
            dataList.size

        }else{
            0
        }

    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {

        val user = dataList[position]

        holder.bindView(user)


    }
    inner class MainViewHolder(itemView: View, listener: ClickListener, longClickListener: LongClickListener): RecyclerView.ViewHolder(itemView), View.OnClickListener, View.OnLongClickListener{
        fun bindView(user: Productos){ // crearé una clase para mis usuarios
            // inflaré la imagen de imagenUrl dentro de la vista circleImageView
            Glide.with(context).load(user.imagen).into(itemView.imagenView)
            itemView.txt_producto.text = user.producto
            itemView.txt_precio.text = user.precio


        }
        var producto: TextView? = null
        var precio: TextView? = null
        var imagen: CircleImageView? = null
        private var listener:ClickListener? = null  //7 lo inicio en el init
        //defino la variable lonClick
        private var longListener: LongClickListener? = null // la inicio en el init

        init {
            producto = itemView.findViewById(R.id.txt_producto)
            precio = itemView.findViewById(R.id.txt_precio)
            imagen = itemView.findViewById(R.id.imagenView)
            this.listener = listener // 8 lo añado junto al metodo (vista: View) en el class ViewHolder.
            this.longListener = longClickListener  // lo mando a llamar en la fun onLingClick 20

            itemView.setOnClickListener(this)
            itemView.setOnLongClickListener(this)
        }

        override fun onClick(v: View?) {
            this.listener?.onClick(v!!, adapterPosition)        }

        override fun onLongClick(v: View?): Boolean {
            this.longListener?.longClick(v!!, adapterPosition)
            return true         }
    }
}
