package com.example.proyectofederico.paqueteMain

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofederico.Actividades.VistaProducto
import com.example.proyectofederico.AdaptadorRecycler
import com.example.proyectofederico.ClicksListener.ClickListener
import com.example.proyectofederico.ClicksListener.LongClickListener
import com.example.proyectofederico.MainViewModel
import com.example.proyectofederico.Productos
import com.example.proyectofederico.R
import com.google.protobuf.Internal
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.template_lista.*

class MainActivity : AppCompatActivity() {
    // le daré clic al recycler
    var recyclerView: RecyclerView? = null
    var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: AdaptadorRecycler? = null

    // inicializo el viewModel
    private val viewModel by lazy { ViewModelProviders.of(this).get(MainViewModel::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // para actualizar la app moviendo el dedo hacia abajo

        swiperefreshlayout.setOnRefreshListener {
            observeData()
        }
        // sera mi adaptador

        //asocio el recycler a mi main activity
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView?.setHasFixedSize(true)

        layoutManager = LinearLayoutManager(this)
        recyclerView?.layoutManager = layoutManager
        val productos = ArrayList<Productos>()

        adapter = AdaptadorRecycler(productos, applicationContext, object : ClickListener {
            override fun onClick(vista: View, index: Int) {
              val intent =Intent(applicationContext, VistaProducto::class.java)

                startActivity(intent)
            }

        }, object : LongClickListener {
            override fun longClick(vista: View, index: Int) {
            }

        } )
         // esto es muy parecido a un listview. asi que deberia crear un ArrayList. arriba de lista. debajo del onCreate
        recyclerView?.adapter = adapter


        observeData()
    }

    fun observeData(){
        viewModel.fetchUserData().observe(this, Observer {
            swiperefreshlayout.isRefreshing = false
            adapter!!.setListData(it)
            adapter!!.notifyDataSetChanged()
        })
    }

}
