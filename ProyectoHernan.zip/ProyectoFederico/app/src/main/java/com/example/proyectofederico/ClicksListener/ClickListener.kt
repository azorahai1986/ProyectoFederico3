package com.example.proyectofederico.ClicksListener

import android.view.View

interface ClickListener {
    fun onClick (vista: View, index: Int)

}